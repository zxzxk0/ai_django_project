from django.shortcuts import render, redirect ,HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from .forms import SignUpForm
from django.contrib import auth
from django.http import StreamingHttpResponse
from django.views.decorators import gzip
import cv2, time


import threading

from django.template.loader import get_template 
# Create your views here.


def home(request):
    return render(request, "home.html")
 
def page(request):
    return render(request, "page.html")

def page1(request):
    
    if request.method == 'POST':
        form = SignUpForm(request.POST)

        if form.is_valid():
            user = form.save()

            login(request, user)
        return redirect("page2")
        
    return render(request, "page1.html")
    

def page2(request):
    return render(request, "page2.html")

def page3(request):
    return render(request, "page3.html")



def face(request):
    template = get_template('face.html')
    return HttpResponse(template.render({}, request))
def stream():
    cap = cv2.VideoCapture(0) 

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: failed to capture image")
            break

        cv2.imwrite('demo.jpg', frame)
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + open('demo.jpg', 'rb').read() + b'\r\n')

def video(request):
            

        try:
            time.sleep(2)
            return StreamingHttpResponse(stream(), content_type='multipart/x-mixed-replace; boundary=frame')
        except HttpResponseServerError as e:
            print("asborted", e)


def page4(request):
    return render(request, "page4.html")

def page5(request):
    return render(request, "page5.html")

def page6(request):
    return render(request, "page6.html")

def page7(request):
    return render(request, "page7.html")

def page8(request):
    return render(request, "page8.html")

def page9(request):
    return render(request, "page9.html")

def page10(request):
    return render(request, "page10.html")


def page7p(request):
    return render(request, "page7p.html")

def page8p(request):
    return render(request, "page8p.html")

def page9p(request):
    return render(request, "page9p.html")

def neg1(request):
    return render(request, "neg1.html")

def neg2(request):
    return render(request, "neg2.html")

def pos1(request):
    return render(request, "pos1.html")

def pos2(request):
    return render(request, "pos2.html")

def page11(request):
    return render(request, "page11.html")

def page12(request):
    return render(request, "page12.html")

def last(request):
    return render(request, "last.html")

