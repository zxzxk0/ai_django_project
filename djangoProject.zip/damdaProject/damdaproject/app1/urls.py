from django.urls import path
from .import views

from django.conf.urls.static import static
from django.conf import settings

from app1.views import face, video
urlpatterns = [
    path("home/", views.home , name="damda-home"),

    path("", views.page, name="page" ),
    path("page1/", views.page1, name="page1" ),
    path("page2/", views.page2, name="page2" ),
    path("page3/", views.page3, name="page3" ),

    path("face/", views.face, name="face" ),
    path('video', video, name="video"),
    path("page4/", views.page4, name="page4" ),
    path("page5/", views.page5, name="page5" ),
    path("page6/", views.page6, name="page6" ),
    path("page7/", views.page7, name="page7" ),
    path("page8/", views.page8, name="page8" ),
    path("page9/", views.page9, name="page9" ),
    path("page10/", views.page10, name="page10" ),
    path("page7p/", views.page7p, name="page7p" ),
    path("page8p/", views.page8p, name="page8p" ),
    path("page9p/", views.page9p, name="page9p" ),

    path("page11", views.page11, name="page11" ),
    path("page12/", views.page12, name="page12" ),
    path("last/", views.page12, name="last" ),
    


]

urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:  # new
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)